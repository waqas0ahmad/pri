var mongoose = require('mongoose');
var videoModel = require('../../models/video/index');
require("dotenv").config();
var videoController = {
    getAllVideos: () => {
        return new Promise((resolve, reject) => {
            mongoose.connect(process.env.MONGOURL,{useNewUrlParser:true});
            let db=mongoose.connection;
            db.on("error",(err)=>{
                reject(err);
            });
            db.once('open',()=>{
                let video=mongoose.model("video",videoModel.model);
                
               
                var all=video.find({});
                resolve(all);
            })
        })
    },
    postVideo:(data)=>{
        return new Promise((resolve,reject)=>{
            mongoose.connect(process.env.MONGOURL,{useNewUrlParser:true});
            let db=mongoose.connection;
            db.on("error",(err)=>{
                reject(err);
            });
            db.once('open',()=>{                
                let video=mongoose.model("video",videoModel.model);
                var items=video.find({}).sort("-OrderNo").exec((e,s)=>{
                    console.log(e);
                    if(s.length>0)
                    data["OrderNo"]=(s[0].OrderNo+1);
                    else
                    data["OrderNo"]=1;
                    video.collection.insertOne(data,(err,docs)=>{
                        if(err) reject(err);
                        else
                        resolve(docs);
                    });
                });
                    // var oN=items.schema.obj.OrderNo();
                    
                
            });
        });
    },
    saveOrder:(data)=>{
        return new Promise((resolve,reject)=>{
            mongoose.connect(process.env.MONGOURL,{useNewUrlParser:true});
            let db=mongoose.connection;
            db.on("error",(err)=>{
                reject(err);
            });
            db.once('open',()=>{
                let video=mongoose.model("video",videoModel.model);
                data.forEach((i,n)=>{
                    let q={VideoUrl:i["VideoUrl"]};
                    video.update(q,{$set:{OrderNo:i["OrderNo"]}}, function (err, user) {
                        if (err) throw error
                        console.log(user)
                        console.log("update user complete")
                    });
                })
               //video.update(data);
               // resolve(video.findOne());
            })
        });
    }
}


module.exports = videoController;
