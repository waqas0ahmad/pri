var mt = require('media-thumbnail');
const Thumbler = require('thumbler');
var root = `/api/video`;
module.exports = (app) => {

    var vidCtrl = require('../Controllers/videoController/index');
    app.get(`${root}`, (req, res) => {
        vidCtrl["getAllVideos"]().then((success) => {
            res.status(200).send(success);
        }).catch((err) => {
            res.status(500).send(err);
        })
    });
    app.post(`${root}/postVideo`, async (req, res) => {
        if (!req.files) {
            res.status(500).send("no file");
            return;
        }
        let file = req.files["uploadFile"];
        let timestamp = new Date().getUTCMilliseconds();
        var filePath = `public/uploads/${timestamp}-${file.name}`;


        file.mv(filePath, (re) => {
            let thumbnailUrl = `${timestamp}-thumb.png`;
            Thumbler({
                type: 'video',
                input: filePath,
                output: `public/uploads/${thumbnailUrl}`,
                time: '00:00:02',
                size: '200x200' // this optional if null will use the desimention of the video
            }, function (err, path) {
                if (err) { res.status(500).send(err); return; };
                var data = { "Title": req.body["Title"], "Description": req.body["Description"], "ThumbnailImage": `public/uploads/${thumbnailUrl}`, "VideoUrl": filePath };
                vidCtrl["postVideo"](data).then((success) => {
                    res.status(200).send(success);
                }).catch((err) => {
                    res.status(500).send(err);
                });
            });
        });

    });
    app.post(`${root}/saveOrder`, (req, res) => {
        vidCtrl["saveOrder"](req.body).then(
            (success) => { 

            },
            (error) => {

            }
        )
    });
}