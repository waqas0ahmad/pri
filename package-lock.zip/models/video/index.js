var mongoose = require('mongoose');
module.exports={
    model:new mongoose.Schema({
    Title:String,
    Description:String,
    ThumbnailImage:String,
    VideoUrl:String,
    OrderNo:Number
})
}
