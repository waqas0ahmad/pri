const express = require('express'); // Injecting Our Configuration
const app = express()
const cors = require('cors')
var mongoose = require('mongoose')
const path = require('path')
var routes = require('./Routes/index');
const fileUpload = require('express-fileupload');
app.use(cors())
app.use('/', express.static(path.join(__dirname, '/public/*')));
app.use('/public/uploads', express.static(path.join(__dirname, '/public/uploads')));

const bodyParser = require('body-parser')
const http = require('http').Server(app)

require('dotenv').config()
app.use(fileUpload({
    createParentPath: true
}));
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use('/', function (request, response, next) {
  request.headers.lang = request.headers.lang || 'default'
  //console.log(`IP: ${request.connection.remoteAddress} Method: ${request.method} Route: ${request.originalUrl} Body: ` + JSON.stringify(request.body))
  next()
});

routes(app);
app.get("/",(req,res)=>{
res.status(200).send("Ok");

})
http.listen(process.env.PORT, function () {
  console.log('Server is running on http://localhost:' + process.env.PORT)
})

