import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'multipart/form-data'
    })
};
@Component({
    selector: 'app-video-upload',
    templateUrl: './video-upload.component.html',
    styleUrls: ['./video-upload.component.css']
})
export class VideoUploadComponent implements OnInit {

    formData: FormData;
    constructor(private http: HttpClient) {
        this.formData = new FormData();
    }
    title: string;
    description: string;
    ngOnInit() {
    }
    onSubmit() {
        debugger;
        this.formData.append("Title", this.title);
        this.formData.append("Description", this.description);
        this.http.post(`http://localhost:3002/api/video/postVideo`, this.formData)
            .subscribe(
                data => { console.log('success'); location.reload();},
                error => console.log(error)
            )
    }
    onFileChange(event) {
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            let file: File = fileList[0];
            this.formData.append('uploadFile', file, file.name);
            //let headers = new Headers();
            //headers.append('Content-Type', 'multipart/form-data');
            //headers.append('Accept', 'application/json');
            //this.http.post(`http://localhost:3002/api/video/postVideo`, formData)
            //    .subscribe(
            //        data => console.log('success'),
            //        error => console.log(error)
            //    )
        }
    }
}
