import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
    selector: 'app-video-list',
    templateUrl: './video-list.component.html',
    styleUrls: ['./video-list.component.css']
})
export class VideoListComponent implements OnInit {
    domain: string = "http://localhost:3002";
    data: any[];
    constructor(private http: HttpClient) {
        this.data = [];
    }

    ngOnInit() {
        this.getAllVideos();
    }
    getAllVideos() {
        this.http.get<any[]>(`${this.domain}/api/video`).subscribe(
            success => {
                this.data = success;
                
            },
            error => {

            }
        )
    }
    onSaveOrder() {
        this.http.post(`${this.domain}/api/video/saveOrder`, this.data).subscribe(
            (success) => {
                
            },
            (error) => {

            }
        )
    }
}
