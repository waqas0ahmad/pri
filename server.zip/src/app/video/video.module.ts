import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VideoRoutingModule } from './video-routing.module';
import { VideoComponent } from './video.component';
import { VideoListComponent } from './video-list/video-list.component';
import { VideoUploadComponent } from './video-upload/video-upload.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [VideoComponent, VideoListComponent, VideoUploadComponent],
  imports: [
    CommonModule,
      VideoRoutingModule,
      FormsModule,
    HttpClientModule
  ]
})
export class VideoModule { }
